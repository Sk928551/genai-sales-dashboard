import streamlit as st
import pandas as pd
import plotly.express as px
import os
from dotenv import load_dotenv

# Load .env variables
load_dotenv()

# Streamlit UI Setup
st.set_page_config(page_title="GenAI Sales Dashboard", layout="wide")
st.title("📊 GenAI-Powered Sales Dashboard")

# Load CSV Data
df = pd.read_csv("data/sales_data_250_customers.csv", parse_dates=["Date"])

# Display Raw Data
st.subheader("📋 Raw Sales Data")
st.dataframe(df)

# Sales by Region Over Time
st.subheader("📈 Sales Over Time (By Region)")
fig = px.bar(df, x="Date", y="Sales", color="Region", barmode="group")
st.plotly_chart(fig, use_container_width=True)

# Natural Language Query Section
st.subheader("🤖 Ask a Question About the Data")
query = st.text_input("e.g. Which product sold most in South region?", value="highest sales")

if query:
    # Simulated AI Response for Screenshot
    st.success("✅ AI Response:")
    st.markdown("""
    The highest sales were recorded for **Product A** in the **North** region  
    with total sales of **₹1,28,500**.  
    This region consistently outperformed others across all months.
    """)